# Spindler
A python package to compute the long-term orbital evolution of a binary interacting with a circumbinary disk.